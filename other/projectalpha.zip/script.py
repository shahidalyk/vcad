import time,os

i = 1
b = 55+6+6
f = open("myfile.txt","w")
f.write("Hewllooooo")
f.close()
