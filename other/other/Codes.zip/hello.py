import android, time

droid = android.Android()

while 1:
	droid.makeToast("Hello from VCFAD")
	time.sleep(5)
